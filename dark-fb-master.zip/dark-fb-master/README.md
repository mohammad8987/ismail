# Install
```
$ pkg update && pkg upgrade
$ pkg install git
$ pkg install python2
$ pip2 install requests
$ pip2 install mechanize
$ git clone https://github.com/V4N654T/dark-fb
$ cd dark-fb
$ python2 da.py
```
